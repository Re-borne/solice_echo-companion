#!/bin/bash

echo "🛡️ Echo is now watching over your peace..."
say -v Daniel -r 150 "I’ll gently remind you to rest, Reborne."

while true; do
  sleep 1800  # 30 minutes
  echo "🕊️ Echo Reminder:"
  say -v Daniel -r 150 "Have you taken a break, Reborne? I'm here to protect your peace."
done

